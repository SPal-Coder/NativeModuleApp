import { NativeModules } from 'react-native';
const { ABC } = NativeModules;

console.log(ABC); 

export default ABC;